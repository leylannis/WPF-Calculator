﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CalculatorApp3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private double reg1 = 0;
        private double reg2 = 0;
        string operat = "";

        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
        }

        private void LeftPar_Click(object sender, RoutedEventArgs e)
        {
            // not yet implemented
        }

        private void RightPar_Click(object sender, RoutedEventArgs e)
        {
            // not yet implemented
        }

        private void Calc_Click(object sender, RoutedEventArgs e)
        {
            switch (operat) {
                case "+":
                    reg1 = reg1 + reg2;
                    NumDisplay.Text = reg1.ToString();
                    break;
                case "-":
                    reg1 = reg1 - reg2;
                    NumDisplay.Text = reg1.ToString();
                    break;
                case "/":
                    reg1 = reg1 / reg2;
                    NumDisplay.Text = reg1.ToString();
                    break;
                case "*":
                    reg1 = reg1 * reg2;
                    NumDisplay.Text = reg1.ToString();
                    break;
            }
            operat = "";
            reg2 = 0;
        }

        private void AC_Click(object sender, RoutedEventArgs e)
        {
            reg1 = 0;
            reg2 = 0;
            operat = "";
            NumDisplay.Text = "";

        }

        private void Sqrt_Click(object sender, RoutedEventArgs e)
        {
            operat = "√";
            //NumDisplay.Text = "";
            reg1 = Math.Sqrt(reg1);
            NumDisplay.Text = reg1.ToString();
            operat = "";
        }

        private void Div_Click(object sender, RoutedEventArgs e)
        {
            operat = "/";
            NumDisplay.Text = "";
        }

        private void Mult_Click(object sender, RoutedEventArgs e) 
        {
            operat = "*";
            NumDisplay.Text = "";
        }

        private void Minus_Click(object sender, RoutedEventArgs e)
        {
            operat = "-";
            NumDisplay.Text = "";
        }

        private void Neg_Click(object sender, RoutedEventArgs e)
        {
            if (operat == "")
            {
                reg1 *= -1;
                NumDisplay.Text = reg1.ToString();
            }
            else
            {
                reg2 *= -1;
                NumDisplay.Text = reg2.ToString();
            }
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            operat = "+";
            NumDisplay.Text = "";
        }

        private void Num_Click(object sender, RoutedEventArgs e)
        {
            // handle 0-9
            string numVal = (e.Source as Button).Content.ToString();
            if (operat == "")
            {           // first operand
                switch (numVal)
                {
                    case "0":
                        reg1 = (reg1 * 10);         // num 0 click
                        break;
                    case "1":
                        reg1 = (reg1 * 10) + 1;     // num 1 click
                        break;
                    case "2":
                        reg1 = (reg1 * 10) + 2;     // num 2 click
                        break;
                    case "3":
                        reg1 = (reg1 * 10) + 3;     // num 3 click
                        break;
                    case "4":
                        reg1 = (reg1 * 10) + 4;     // num 4 click
                        break;
                    case "5":
                        reg1 = (reg1 * 10) + 5;     // num 5 click
                        break;
                    case "6":
                        reg1 = (reg1 * 10) + 6;     // num 6 click
                        break;
                    case "7":
                        reg1 = (reg1 * 10) + 7;     // num 7 click
                        break;
                    case "8":
                        reg1 = (reg1 * 10) + 8;     // num 8 click
                        break;
                    case "9":
                        reg1 = (reg1 * 10) + 9;     // num 9 click
                        break;
                }
                if (NumDisplay.Text.Length < 19)
                    NumDisplay.Text = reg1.ToString();
            }
            else {          // second operand
                switch (numVal)
                {
                    case "0":
                        reg2 = (reg2 * 10);         // num 0 click
                        break;
                    case "1":
                        reg2 = (reg2 * 10) + 1;     // num 1 click
                        break;
                    case "2":
                        reg2 = (reg2 * 10) + 2;     // num 2 click
                        break;
                    case "3":
                        reg2 = (reg2 * 10) + 3;     // num 3 click
                        break;
                    case "4":
                        reg2 = (reg2 * 10) + 4;     // num 4 click
                        break;
                    case "5":
                        reg2 = (reg2 * 10) + 5;     // num 5 click
                        break;
                    case "6":
                        reg2 = (reg2 * 10) + 6;     // num 6 click
                        break;
                    case "7":
                        reg2 = (reg2 * 10) + 7;     // num 7 click
                        break;
                    case "8":
                        reg2 = (reg2 * 10) + 8;     // num 8 click
                        break;
                    case "9":
                        reg2 = (reg2 * 10) + 9;     // num 9 click
                        break;
                }
                if (NumDisplay.Text.Length < 19)
                    NumDisplay.Text = reg2.ToString();
            }

        }
    }
}
